$(document).ready(function() {

    $('#navbarNav')[0].classList.remove('mt-3');

    $('#header-address-nav')[0].classList.remove('d-sm-block')
    $('#header-phone-nav')[0].classList.remove('d-sm-block')
    $('#header-address')[0].classList.remove('d-block')
    $('#header-phone')[0].classList.remove('d-block')
})