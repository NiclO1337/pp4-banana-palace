// Add on click function to footer links extra to display an error message
$(document).ready(function () {

    let errorMessage = $('.error-msg-links')[0];

    $('.footer-links-extra').children('li').click(function () {

        errorMessage.style.display = "block";
        $('.footer-links-extra').children('li').addClass("d-none");

        window.setTimeout(() => {
            errorMessage.style.opacity = "1";
        }, 100)
        window.setTimeout(() => {
            errorMessage.style.opacity = "0";
        }, 5100)
        window.setTimeout(() => {
            errorMessage.style.display = "none";
            $('.footer-links-extra').children('li').removeClass("d-none");
        }, 6100)
    })
})
